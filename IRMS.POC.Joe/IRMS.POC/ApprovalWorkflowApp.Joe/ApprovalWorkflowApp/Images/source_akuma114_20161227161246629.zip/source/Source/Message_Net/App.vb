Public Class App

    Public Shared MainForm As frmMain

End Class

<ComClass(ComExpose.ClassId, ComExpose.InterfaceId, ComExpose.EventsId)> _
Public Class ComExpose

#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "3d9e2e6f-5bf2-4144-8790-4e5b0af104e9"
    Public Const InterfaceId As String = "b89d94d5-2306-4afc-a3b5-e86a1958fb9d"
    Public Const EventsId As String = "1e3a740b-f7a9-4d31-9a7d-db11210f0c01"
#End Region

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub


    Public Sub StartApplication()

        '****************************************************************************************************
        ' THIS METHOD MUST BE CALLED BY AN OUT OF PROCESS COM SERVER to start the .Net application!!!!
        '****************************************************************************************************

        ' create the new form
        Dim frm As frmMain
        frm = New frmMain()

        ' save the reference to the form in a static variable
        App.MainForm = frm

        frm.ListBox1.Items.Add(".Net application starting")

        ' show the form
        frm.ShowDialog()

    End Sub

    '***********************************************************************************
    ' this method displays the message from the parameter in the list box in frmMain.
    '***********************************************************************************
    Public Sub DisplayMessage(ByVal Message As String)

        If Not App.MainForm Is Nothing Then
            App.MainForm.ListBox1.Items.Insert(0, DateTime.Now.ToLongTimeString() & " - " & Message)
        End If

    End Sub

End Class



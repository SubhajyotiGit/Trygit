Public Class frmMain

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Me.ListBox1.Items.Insert(0, DateTime.Now.ToLongTimeString() & " - Hello World!  this was added internally")

        ' Alternativly, we could use the ComExpose object for adding items directly to the list box
        'Dim MyComExpose As ComExpose

        'MyComExpose = New ComExpose()
        'MyComExpose.DisplayMessage("Hello World!  This was added internally through the ComExpose object")

    End Sub

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' save a reference of this object in the App shared variable
        '   (if it's not already there!)
        If App.MainForm Is Nothing Then App.MainForm = Me

    End Sub
End Class
